﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BigBlueButton;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Security.Cryptography;
using System.Data;
using System.Net;


    class Program
    {
       
 
        static void Main(string[] args)
        {
             //ServiceReference1.ServiceClient objtest = new ServiceReference1.ServiceClient();
           //  string strresult=objtest.CreateRoom(5, 234, "testroom", "fd", "ghfg", "testing simply", 1);
             DataTable dt = new DataTable();
             ClsBigBlueButton ObjBigBlueButton = new ClsBigBlueButton();
             //Console.WriteLine(ClsData.getSha1("createname=Test+Meeting&meetingID=abc123&attendeePW=111222&moderatorPW=33344404f3591a48c820cebfe5096e6cffd0b3"));
             dt = ObjBigBlueButton.CreateMeeting("Mkalaiselvi", "a2b", "selvi", "kalai");
             ObjBigBlueButton.JoinMeeting("Mkalaiselvi", "a2b", "kalai", true);
             ObjBigBlueButton.JoinMeeting("Mkalaiselvi", "a2b", "selvi", true);
             dt = ObjBigBlueButton.IsMeetingRunning("a2b");
             dt =ObjBigBlueButton.getMeetings();
             dt = ObjBigBlueButton.GetMeetingInfo("a2b", "kalai");
             dt = ObjBigBlueButton.EndMeeting("a2b", "kalai");
             dt =ObjBigBlueButton.IsMeetingRunning("aaa");          
             Console.ReadLine();         
         
        }
       
    }

